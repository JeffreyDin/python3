# 网络带宽计算
# print(100/8)

bandwidth = 100
ratio = 8

print(bandwidth/ratio)

bandWidth
BandWidth
band_width
