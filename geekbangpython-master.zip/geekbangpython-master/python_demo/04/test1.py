# 输出一行文字
print('hello time.geerbang!')

