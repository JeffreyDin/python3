x = 'abcd'
if x == 'abc' :
    print('x 的值和abc 相等')
else:
    print('x和 abc不相等')