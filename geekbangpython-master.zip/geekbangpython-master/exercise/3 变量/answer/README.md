# 练习一 变量的定义和使用

```python
# 定义美元
dollar = 100
# 定义汇率
exchange = 6.4696

# 输出结果
print('{dol}美元兑换的人民币数量为{yuan}'.format(dol=dollar, yuan=dollar * exchange))
```

